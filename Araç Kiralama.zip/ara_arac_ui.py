# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ara_arac.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QVBoxLayout, QWidget)

class Ui_araarac(object):
    def setupUi(self, araarac):
        if not araarac.objectName():
            araarac.setObjectName(u"araarac")
        araarac.resize(730, 225)
        self.horizontalLayoutWidget = QWidget(araarac)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(20, 20, 691, 121))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.label_4 = QLabel(self.horizontalLayoutWidget)
        self.label_4.setObjectName(u"label_4")

        self.horizontalLayout_4.addWidget(self.label_4)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_3 = QLabel(self.horizontalLayoutWidget)
        self.label_3.setObjectName(u"label_3")

        self.horizontalLayout_3.addWidget(self.label_3)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.label_6 = QLabel(self.horizontalLayoutWidget)
        self.label_6.setObjectName(u"label_6")

        self.horizontalLayout_6.addWidget(self.label_6)


        self.verticalLayout.addLayout(self.horizontalLayout_6)


        self.horizontalLayout.addLayout(self.verticalLayout)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.label_7 = QLabel(self.horizontalLayoutWidget)
        self.label_7.setObjectName(u"label_7")

        self.horizontalLayout_8.addWidget(self.label_7)


        self.verticalLayout_2.addLayout(self.horizontalLayout_8)

        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.label_5 = QLabel(self.horizontalLayoutWidget)
        self.label_5.setObjectName(u"label_5")

        self.horizontalLayout_7.addWidget(self.label_5)


        self.verticalLayout_2.addLayout(self.horizontalLayout_7)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.label_8 = QLabel(self.horizontalLayoutWidget)
        self.label_8.setObjectName(u"label_8")

        self.horizontalLayout_9.addWidget(self.label_8)


        self.verticalLayout_2.addLayout(self.horizontalLayout_9)


        self.horizontalLayout.addLayout(self.verticalLayout_2)

        self.verticalLayoutWidget_3 = QWidget(araarac)
        self.verticalLayoutWidget_3.setObjectName(u"verticalLayoutWidget_3")
        self.verticalLayoutWidget_3.setGeometry(QRect(120, 20, 211, 121))
        self.verticalLayout_3 = QVBoxLayout(self.verticalLayoutWidget_3)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.line_marka = QLineEdit(self.verticalLayoutWidget_3)
        self.line_marka.setObjectName(u"line_marka")

        self.verticalLayout_3.addWidget(self.line_marka)

        self.line_model = QLineEdit(self.verticalLayoutWidget_3)
        self.line_model.setObjectName(u"line_model")

        self.verticalLayout_3.addWidget(self.line_model)

        self.line_yil = QLineEdit(self.verticalLayoutWidget_3)
        self.line_yil.setObjectName(u"line_yil")

        self.verticalLayout_3.addWidget(self.line_yil)

        self.verticalLayoutWidget_4 = QWidget(araarac)
        self.verticalLayoutWidget_4.setObjectName(u"verticalLayoutWidget_4")
        self.verticalLayoutWidget_4.setGeometry(QRect(480, 20, 181, 121))
        self.verticalLayout_4 = QVBoxLayout(self.verticalLayoutWidget_4)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.line_motor_no = QLineEdit(self.verticalLayoutWidget_4)
        self.line_motor_no.setObjectName(u"line_motor_no")

        self.verticalLayout_4.addWidget(self.line_motor_no)

        self.line_plaka = QLineEdit(self.verticalLayoutWidget_4)
        self.line_plaka.setObjectName(u"line_plaka")

        self.verticalLayout_4.addWidget(self.line_plaka)

        self.line_renk = QLineEdit(self.verticalLayoutWidget_4)
        self.line_renk.setObjectName(u"line_renk")

        self.verticalLayout_4.addWidget(self.line_renk)

        self.push_bul = QPushButton(araarac)
        self.push_bul.setObjectName(u"push_bul")
        self.push_bul.setGeometry(QRect(250, 150, 231, 51))

        self.retranslateUi(araarac)

        QMetaObject.connectSlotsByName(araarac)
    # setupUi

    def retranslateUi(self, araarac):
        araarac.setWindowTitle(QCoreApplication.translate("araarac", u"Form", None))
        self.label_4.setText(QCoreApplication.translate("araarac", u"Marka", None))
        self.label_3.setText(QCoreApplication.translate("araarac", u"Model", None))
        self.label_6.setText(QCoreApplication.translate("araarac", u"\u00dcretim Y\u0131l\u0131", None))
        self.label_7.setText(QCoreApplication.translate("araarac", u"Motor No", None))
        self.label_5.setText(QCoreApplication.translate("araarac", u"Plaka", None))
        self.label_8.setText(QCoreApplication.translate("araarac", u"Renk", None))
        self.push_bul.setText(QCoreApplication.translate("araarac", u"Bul", None))
    # retranslateUi

